﻿
Partial Class Client_AboutUs
    Inherits System.Web.UI.Page

End Class
