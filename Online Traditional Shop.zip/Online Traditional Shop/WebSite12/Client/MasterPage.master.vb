﻿
Partial Class Client_MasterPage
    Inherits System.Web.UI.MasterPage

    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        Response.Redirect("search.aspx?search=" + Txt_search.Text)
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("UserId") = "abc" And Session("UserPassword") = "abc" Then
            'MsgBox("session IN")
            Btn_logout.Visible = True
            Lbl_login.Visible = False
        Else
            'MsgBox("session out")
            Btn_logout.Visible = False
            Lbl_login.Visible = True
        End If
    End Sub

    'logout
    Protected Sub Btn_logout_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Btn_logout.Click
        Session("UserId") = ""
        Session("UserPassword") = ""
        Response.Redirect("Login.aspx")
    End Sub
End Class

