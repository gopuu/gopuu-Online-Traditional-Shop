﻿
Partial Class Client_gowns
    Inherits System.Web.UI.Page

    'ViewProduct button command click
    Protected Sub ImageButton1_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        If e.CommandName = "productview" Then
            Response.Redirect("ProductView.aspx?id=" + e.CommandArgument.ToString)
        End If
    End Sub

    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)

    End Sub

    'addToCart button command click
    Protected Sub ImageButton2_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        If e.CommandName = "addtocart" Then
            Response.Redirect("Add2Cart.aspx?id=" + e.CommandArgument.ToString)
        End If
    End Sub
End Class
