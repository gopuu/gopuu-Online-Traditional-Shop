﻿
Partial Class Client_Lehengas
    Inherits System.Web.UI.Page
    'addtocart click
    Protected Sub ImageButton2_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)

    End Sub
    'view button click
    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        'Response.Redirect("ProductView.aspx?id")
    End Sub
    'view button
    Protected Sub ImageButton1_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        If e.CommandName = "productview" Then
            Response.Redirect("ProductView.aspx?id=" + e.CommandArgument.ToString)
        End If

    End Sub
    'addtocart button click
    Protected Sub ImageButton2_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        
    End Sub
    'addToCart button command click
    Protected Sub ImageButton2_Command1(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        If e.CommandName = "addtocart" Then
            Response.Redirect("Add2Cart.aspx?id=" + e.CommandArgument.ToString)
        End If
    End Sub
End Class
