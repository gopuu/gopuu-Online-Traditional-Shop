﻿Partial Class Client_index
    Inherits System.Web.UI.Page
    'img 1
    Protected Sub ImageButton9_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton9.Click
        Response.Redirect(String.Format("https://www.instagram.com/p/BlkSd-xB_4D/?taken-by=brandz.4u"))
    End Sub
    'img 2
    Protected Sub ImageButton16_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton16.Click
        Response.Redirect(String.Format("https://www.instagram.com/p/BkvBCXZBecg/?taken-by=brandz.4u"))
    End Sub

    'img 3
    Protected Sub ImageButton13_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton13.Click
        Response.Redirect(String.Format("https://www.instagram.com/p/BkCXeO4gGek/?taken-by=brandz.4u"))
    End Sub
    'img 4
    Protected Sub ImageButton14_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton14.Click
        Response.Redirect(String.Format("https://www.instagram.com/p/BlBCadxhWaL/?taken-by=brandz.4u"))
    End Sub
    'img 5
    Protected Sub ImageButton15_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton15.Click
        Response.Redirect(String.Format("https://www.instagram.com/p/BklA69ZAOk5/?taken-by=brandz.4u"))
    End Sub
    'img 6
    Protected Sub ImageButton17_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton17.Click
        Response.Redirect(String.Format("https://www.instagram.com/p/BkqAImGhRaf/?taken-by=brandz.4u"))
    End Sub

    'img 7
    Protected Sub ImageButton18_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton18.Click
        Response.Redirect(String.Format("https://www.instagram.com/p/BlGdav6hdW4/?taken-by=brandz.4u"))
    End Sub

    'img 8
    Protected Sub ImageButton19_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton19.Click
        Response.Redirect(String.Format("https://www.instagram.com/p/BlcssyqgroK/?taken-by=brandz.4u"))
    End Sub
    'img 9
    Protected Sub ImageButton20_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton20.Click
        Response.Redirect(String.Format("https://www.instagram.com/p/BlVU_cqh6OJ/?taken-by=brandz.4u"))
    End Sub
    
    'img 10
    Protected Sub ImageButton21_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton21.Click
        Response.Redirect(String.Format("https://www.instagram.com/p/BkAncrsg563/?taken-by=brandz.4u"))
    End Sub
End Class
