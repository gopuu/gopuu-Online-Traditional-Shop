﻿
Partial Class Client_search
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Request.QueryString("search") = "lehenga" Or Request.QueryString("search") = "lehega" Or Request.QueryString("search") = "lehengas" Then
            Response.Redirect("lehengas.aspx")
        ElseIf Request.QueryString("search") = "gowns" Or Request.QueryString("search") = "gown" Then
            Response.Redirect("gowns.aspx")
        ElseIf Request.QueryString("search") = "kurti" Or Request.QueryString("search") = "dress" Then
            Response.Redirect("Dresses.aspx")
        ElseIf Request.QueryString("search") = "saree" Or Request.QueryString("search") = "sarees" Then
            Response.Redirect("Sarees.aspx")
        ElseIf Request.QueryString("search") = "Salwar" Or Request.QueryString("search") = "Salwars" Then
            Response.Redirect("Salwar.aspx")
        Else
            Response.Write("<h1 style='margin:12% 0 0 5%;color:red;'>Not Results..!!</h1>")
        End If
    End Sub
End Class
