﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class Client_Payment
    Inherits System.Web.UI.Page
    'variables
    Dim cnn As New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\gopuu__\Documents\Visual Studio 2010\WebSites\WebSite12\App_Data\Brandz4u_DB.mdf;Integrated Security=True;User Instance=True")
    Dim cmd As SqlCommand
    Dim qry As String

    'load
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim dt As DataTable = Session("SHOPitems")
        GridView1.DataSource = dt
        GridView1.DataBind()
    End Sub

    'submit
    Protected Sub Btn_submit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_submit.Click
        Try
            cnn.Open()
            qry = "insert into orders(email,fname,lname,country,pincode,address,landmark,mobile) values('" + _
                Txt_email.Text + "','" + Txt_fname.Text + "','" + Txt_lname.Text + "','" + txt_country.Text + "','" + _
                Txt_pincode.Text + "','" + Txt_address.Text + "','" + Txt_landmark.Text + "','" + Txt_phone.Text + "')"
            cmd = New SqlCommand(qry, cnn)
            If cmd.ExecuteNonQuery Then
                Response.Redirect("Success.aspx")
            Else
                Response.Write("<script> alert('Data insertion FAIL. Check all Fields..!!'); </script>")
            End If
            cnn.Close()
        Catch ex As Exception
            Response.Write("<script> alert('Data insertion FAIL. Check all Fields..!!'); </script>")
        End Try
    End Sub
End Class
