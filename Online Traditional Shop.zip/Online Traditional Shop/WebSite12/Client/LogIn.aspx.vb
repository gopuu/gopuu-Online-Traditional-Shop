﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class Client_LogIn
    Inherits System.Web.UI.Page
    'variables
    Dim cnn As New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\gopuu__\Documents\Visual Studio 2010\WebSites\WebSite12\App_Data\Brandz4u_DB.mdf;Integrated Security=True;User Instance=True")
    Dim cmd As SqlCommand
    Dim qry As String

    Protected Sub Submit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Submit.Click
        Txt_userid.Text.ToLower()
        Txt_pswd.Text.ToLower()
        If Txt_userid.Text = "abc" And Txt_pswd.Text = "abc" Then
            Session("UserId") = "abc"
            Session("UserPassword") = "abc"
            showFalse()
            'Response.Write("<script> alert('login success..');</script>")
            'MsgBox("In")
            Response.Write("<style type='text/css'>#form{background:url('../pics/slide01.jpg'); </style>")
        Else
            showTrue()
            Response.Write("<script> alert('Incorrect userid or password'); </script>")
        End If
    End Sub
    'page load
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        showTrue()
        Response.Write("<style type='text/css'>#form{background:url('../pics/slide03.jpg'); </style>")
    End Sub

    Function showFalse()
        Txt_pswd.Visible = False
        Txt_userid.Visible = False
        Lbl_forgot.Visible = False
        Lbl_TITLE.Visible = False
        Submit.Visible = False
        Return 0
    End Function

    Function showTrue()
        Txt_pswd.Visible = True
        Txt_userid.Visible = True
        Lbl_forgot.Visible = True
        Lbl_TITLE.Visible = True
        Submit.Visible = True
        Return 0
    End Function

    End Class
