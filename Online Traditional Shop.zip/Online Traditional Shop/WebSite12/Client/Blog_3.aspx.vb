﻿
Partial Class Client_Blog_3
    Inherits System.Web.UI.Page

End Class
