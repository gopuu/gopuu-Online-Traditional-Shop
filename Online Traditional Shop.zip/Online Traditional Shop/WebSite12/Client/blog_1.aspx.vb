﻿
Partial Class Client_blog_1
    Inherits System.Web.UI.Page

End Class
