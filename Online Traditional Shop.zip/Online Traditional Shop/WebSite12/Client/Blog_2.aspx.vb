﻿
Partial Class Client_Blog_2
    Inherits System.Web.UI.Page

End Class
