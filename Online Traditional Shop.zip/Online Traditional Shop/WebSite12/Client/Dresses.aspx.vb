﻿
Partial Class Client_Dresses
    Inherits System.Web.UI.Page

    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)

    End Sub

    Protected Sub ImageButton1_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        If e.CommandName = "productview" Then
            Response.Redirect("productview.aspx?id=" + e.CommandArgument.ToString)
        End If
    End Sub

    Protected Sub ImageButton2_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        If e.CommandName = "addtocart" Then
            Response.Redirect("Add2Cart.aspx?id=" + e.CommandArgument.ToString)
        End If
    End Sub
End Class
