﻿
Partial Class Client_ProductView
    Inherits System.Web.UI.Page

    Protected Sub ImageButton3_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)

    End Sub

    Protected Sub ImageButton3_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        If e.CommandName = "buynow" Then
            Response.Redirect("Payment.aspx?id=" + e.CommandArgument.ToString)
        End If
    End Sub
End Class
