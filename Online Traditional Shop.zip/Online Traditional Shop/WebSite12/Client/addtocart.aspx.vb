﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class Client_addtocart
    Inherits System.Web.UI.Page
    'variables
    Dim cnn As New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\gopuu__\Documents\Visual Studio 2010\WebSites\Shopp1\App_Data\Database.mdf;Integrated Security=True;User Instance=True")
    Dim cmd As SqlCommand
    Dim adap As SqlDataAdapter
    Dim qry As String
    Dim ds As DataSet
    Dim dt As DataTable
    Dim dr As DataRow
    Dim t1, t2, total_payable As Integer

    Function conn()
        cnn.Open()
        qry = "select * from Product_Add where id=" + Request.QueryString("id")
        cmd = New SqlCommand(qry, cnn)
        adap = New SqlDataAdapter()
        adap.SelectCommand = cmd
        ds = New DataSet()
        adap.Fill(ds)
        Return 0
    End Function

    Function fetch_rows()
        dr("name") = ds.Tables(0).Rows(0)("name").ToString()
        dr("description")= ds.Tables(0).Rows(0)("description").ToString();
        dr("price") = ds.Tables(0).Rows(0)("price").ToString();
        dr("Quantity") = ds.Tables(0).Rows(0)("Quantity").ToString();
        dr("image") = ds.Tables(0).Rows(0)("image").ToString();
        t1 = Convert.ToInt32(ds.Tables(0).Rows(0)("price");
        t2 = Convert.ToInt32(ds.Tables(0).Rows(0)("Quantity");
        dr("cost") = t1*t2;
        dr("total") = dr("cost");        
        dt.Rows.Add(dr);
        GridView_CART.DataSource = dt;
        GridView_CART.DataBind();
        Session("SHOPitems") = dt;
        Return 0
    End Function

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'start 1
        If Not Page.IsPostBack Then
            Dim dt As New DataTable
            Dim dr As DataRow
            dt.Columns.Add("srno")
            dt.Columns.Add("id")
            dt.Columns.Add("name")
            dt.Columns.Add("price")
            dt.Columns.Add("image")
            dt.Columns.Add("cost")
            dt.Columns.Add("totalcost")

            'start 1.2
            If Not Request.QueryString("id") = Nothing Then
                'start 1.2.3
                cnn.Open()
                If Not Session("buyitems") = Nothing Then
                    dr = dt.NewRow
                    qry = "select * from product where id=" + Request.QueryString("id")
                    cmd = New SqlCommand(qry, cnn)
                    adap = New SqlDataAdapter(cmd)
                    Dim ds As New DataSet
                    adap.Fill(ds)

                    dr("srno") = 1
                    dr("id") = ds.Tables(0).Rows(0)("id").ToString
                    dr("name") = ds.Tables(0).Rows(0)("name").ToString
                    dr("price") = ds.Tables(0).Rows(0)("price").ToString
                    dr("image") = ds.Tables(0).Rows(0)("image").ToString

                    dt.Rows.Add(dr)
                    GridView1.DataSource = dt
                    GridView1.DataBind()
                    Session("buyitems") = dt
                Else
                    'start 1.2.3.4
                    dt = CType(Session("buyitems"), DataTable)
                    Dim sr As Integer
                    'sr = dt.Rows.Count
                    MsgBox(sr.ToString)
                    dr = dt.NewRow
                    qry = "select * from product where id = " + Request.QueryString("id")
                    cmd = New SqlCommand(qry, cnn)
                    adap = New SqlDataAdapter(cmd)
                    Dim ds As New DataSet
                    adap.Fill(ds)

                    dr("srno") = sr + 1
                    dr("id") = ds.Tables(0).Rows(0)("id").ToString
                    dr("name") = ds.Tables(0).Rows(0)("name").ToString
                    dr("price") = ds.Tables(0).Rows(0)("price").ToString
                    dr("image") = ds.Tables(0).Rows(0)("image").ToString

                    dt.Rows.Add(dr)
                    GridView1.DataSource = dt
                    GridView1.DataBind()
                    Session("buyitems") = dt

                    'end 1.2.3.4
                End If
                'end 1.2.3
            Else
                dt = Session("buyitems")
                GridView1.DataSource = dt
                GridView1.DataBind()
            End If
            'end 1.2
        End If
        'end 1
    End Sub
End Class
