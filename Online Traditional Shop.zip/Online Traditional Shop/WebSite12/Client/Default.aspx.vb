﻿
Partial Class Client_Default
    Inherits System.Web.UI.Page

End Class
