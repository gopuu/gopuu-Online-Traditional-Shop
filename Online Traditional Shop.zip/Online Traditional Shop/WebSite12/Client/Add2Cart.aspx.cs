﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Client_Add2Cart : System.Web.UI.Page
{
    String mycon,myqry;
    SqlConnection scon;
    SqlCommand cmd;
    DataSet ds;
    DataTable dt;
    DataRow dr;
    SqlDataAdapter adap;
    int t1, t2,total_payable;
    void conn()
    {
        mycon = "Data Source=.\\SQLEXPRESS;AttachDbFilename=C:\\Users\\gopuu__\\Documents\\Visual Studio 2010\\WebSites\\WebSite12\\App_Data\\Brandz4u_DB.mdf;Integrated Security=True;User Instance=True";
        scon = new SqlConnection(mycon);
        myqry = "select * from Product_Add where id=" + Request.QueryString["id"];
        cmd = new SqlCommand();
        cmd.CommandText = myqry;
        cmd.Connection = scon;
        adap = new SqlDataAdapter();
        adap.SelectCommand = cmd;
        ds = new DataSet();
        adap.Fill(ds);
    }
    void fetch_rows()
    {
        dr["name"] = ds.Tables[0].Rows[0]["name"].ToString();
        dr["description"] = ds.Tables[0].Rows[0]["description"].ToString();
        dr["price"] = ds.Tables[0].Rows[0]["price"].ToString();
        dr["Quantity"] = ds.Tables[0].Rows[0]["Quantity"].ToString();
        dr["image"] = ds.Tables[0].Rows[0]["image"].ToString();
        
        t1 = Convert.ToInt32(ds.Tables[0].Rows[0]["price"]);
        t2 = Convert.ToInt32(ds.Tables[0].Rows[0]["Quantity"]);
        dr["cost"] = t1*t2;
        //dr["cost"] = t1 * t2;
        
        dr["total"] = dr["cost"];        
        dt.Rows.Add(dr);
        GridView_CART.DataSource = dt;
        GridView_CART.DataBind();
        Session["SHOPitems"] = dt;
    }
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            dt = new DataTable();
            dt.Columns.Add("sno");
            dt.Columns.Add("name");
            dt.Columns.Add("description");
            dt.Columns.Add("price");
            dt.Columns.Add("Quantity");
            dt.Columns.Add("image");
            dt.Columns.Add("cost");
            dt.Columns.Add("total");

            if (Request.QueryString["id"] != null)
            {
                if (Session["SHOPitems"] == null)
                {
                    dr = dt.NewRow();
                    conn();
                    dr["sno"] = 1;
                    fetch_rows();
                }
                else
                {
                    dt = (DataTable)Session["SHOPitems"];
                    int sr;
                    sr = dt.Rows.Count;
                    dr = dt.NewRow();
                    conn();
                    dr["sno"] = sr + 1;
                    fetch_rows();
                }
                lbl_Items.Text = Convert.ToString(dt.Rows.Count);//count total items
                Lbl_totalAmount.Text = Convert.ToString(total_payable);
            }
            else
            {
                dt = (DataTable)Session["SHOPitems"];
                GridView_CART.DataSource = dt;
                GridView_CART.DataBind();
            }
            //Lbl_Items.Text = Convert.ToString(dt.Rows.Count);//count total items
            //Lbl_totalAmount.Text = Convert.ToString(total_payable);
        }
    }
}