﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class Client_SignUp
    Inherits System.Web.UI.Page
    'variables
    Dim cnn As New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\gopuu__\Documents\Visual Studio 2010\WebSites\WebSite12\App_Data\Brandz4u_DB.mdf;Integrated Security=True;User Instance=True")
    Dim cmd As SqlCommand
    Dim qry As String

    Protected Sub btn_submit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_submit.Click
        Try
            Dim name As String = TxtName.Text
            Dim dob As String = TxtDOB.Text
            Dim gender As String = txtGENDER.Text
            Dim email As String = TxtEMAIL.Text
            Dim phone As String = TxtPhone.Text
            Dim pwd As String = TxtPASSWORD.Text
            Dim img As String = txtIMG.FileName

            cnn.Open()
            qry = "insert into Customer_Add(Name,DOB,Gender,Email,Phone,Password,Image) values('" + name + "','" + dob + "','" + gender + "','" + email _
                + "','" + phone + "','" + pwd + "','" + img + "')"
            'MsgBox(qry.ToString)
            cmd = New SqlCommand(qry, cnn)
            If cmd.ExecuteNonQuery Then
                Response.Redirect("index.aspx")
            End If
        Catch ex As Exception
            'MsgBox("insertion fail" + Chr(10) + ex.Message)
        End Try
    End Sub
End Class
