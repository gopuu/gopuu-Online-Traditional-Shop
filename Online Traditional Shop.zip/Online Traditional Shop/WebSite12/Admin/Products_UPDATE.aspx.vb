﻿
Partial Class Admin_Products_UPDATE
    Inherits System.Web.UI.Page

End Class
