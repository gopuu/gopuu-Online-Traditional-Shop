﻿
Partial Class Admin_Settings
    Inherits System.Web.UI.Page

End Class
