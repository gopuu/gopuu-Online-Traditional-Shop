﻿
Partial Class Admin_products
    Inherits System.Web.UI.Page

End Class
