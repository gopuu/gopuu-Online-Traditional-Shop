﻿
Partial Class Admin_Dashboard
    Inherits System.Web.UI.Page

End Class
