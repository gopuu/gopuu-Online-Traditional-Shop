﻿Partial Class Admin_MasterPage_ADMIN
    Inherits System.Web.UI.MasterPage

    'load
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("AdminName") = "ADMIN" And Session("AdminPassword") = "ADMIN" Then
        Else
            Response.Redirect("LogIn.aspx")
        End If
    End Sub

    'logout
    Protected Sub Btn_logout_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Btn_logout.Click
        Session("AdminName") = ""
        Session("AdminPassword") = ""
        Response.Redirect("Login.aspx")
    End Sub

End Class

