﻿
Partial Class Admin_Customers
    Inherits System.Web.UI.Page

    Protected Sub Button_ADD_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button_ADD.Click

    End Sub
End Class
