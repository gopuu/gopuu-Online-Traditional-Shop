﻿Imports System.Data.SqlClient
Imports System.IO

Partial Class Admin_Products_ADD
    Inherits System.Web.UI.Page
    'variables
    Dim cnn As New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\gopuu__\Documents\Visual Studio 2010\WebSites\WebSite12\App_Data\Brandz4u_DB.mdf;Integrated Security=True;User Instance=True")
    Dim cmd As SqlCommand
    Dim qry As String
    Dim str_IMG As String

    'PRODUCT_ADD BUTTON
    Protected Sub Button_ADD_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button_ADD.Click
        Try
            cnn.Open()
            str_IMG = Path.GetFileName(FileUpload1.PostedFile.FileName)
            FileUpload1.PostedFile.SaveAs(Server.MapPath("~/pics/DataBase/Products/") + str_IMG)

            qry = "INSERT INTO Product_Add(Name,Category,Status,Price,Quantity,Color,Description,Image) values('" + txt_Name.Text + "','" + txt_Category.Text + "','" + txt_Status.Text + "'," + txt_Price.Text + "," + txt_QTY.Text + ",'" + txt_Color.Text + "','" + txt_Description.Text + "','" + str_IMG + "')"
            cmd = New SqlCommand(qry, cnn)
            If cmd.ExecuteNonQuery Then
                Response.Redirect("Product_GRIDVIEW.aspx")
            Else
                Response.Write("<script> alert('Data insertion FAIL. Check all Fields..!!'); </script>")
            End If
            cnn.Close()
        Catch ex As Exception
            Response.Write("<script> alert('Data insertion FAIL. Check all Fields..!!'); </script>")
            'Response.Write("ERROR..!! " + ex.ToString)
        End Try
    End Sub

    'CANCEL
    Protected Sub Button_CAncel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button_CAncel.Click
        Response.Redirect("Product_GRIDVIEW.aspx")
    End Sub
End Class
