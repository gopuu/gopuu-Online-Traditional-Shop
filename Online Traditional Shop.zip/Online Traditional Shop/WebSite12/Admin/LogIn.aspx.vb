﻿Partial Class Admin_LogIn
    Inherits System.Web.UI.Page
    'login button
    Protected Sub Submit1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Submit1.Click
        txt_userID.Text = txt_userID.Text.ToUpper
        txt_PASSWORD.Text = txt_PASSWORD.Text.ToUpper
        If txt_userID.Text = txt_PASSWORD.Text Then
            Session("AdminName") = txt_userID.Text
            Session("AdminPassword") = txt_PASSWORD.Text
            Label_ID.Visible = False
            Response.Redirect("Dashboard.aspx")
        Else
            Label_ID.Visible = True
        End If
    End Sub
End Class
