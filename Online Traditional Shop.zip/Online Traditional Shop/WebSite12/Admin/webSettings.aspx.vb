﻿Imports System.Data.SqlClient
Imports System.IO

Partial Class Admin_webSettings
    Inherits System.Web.UI.Page
    'variables
    Dim cnn As New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\gopuu__\Documents\Visual Studio 2010\WebSites\WebSite12\App_Data\Brandz4u_DB.mdf;Integrated Security=True;User Instance=True")
    Dim cmd As SqlCommand
    Dim qry As String
    Dim str_IMG As String

    'upload
    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            cnn.Open()
            str_IMG = Path.GetFileName(FileUpload1.PostedFile.FileName)
            FileUpload1.PostedFile.SaveAs(Server.MapPath("~/pics/whats_New/") + str_IMG)
            cmd = New SqlCommand("insert into WhatsNew values('" + str_IMG + "') ", cnn)
            If cmd.ExecuteNonQuery Then
                Response.Redirect("webSettings.aspx")
            End If
            cnn.Close()
        Catch ex As Exception
            Response.Write("<script> alert(" + ex.ToString + ") </script>")
        End Try
    End Sub
End Class
