﻿
Partial Class Admin_Customer_UPDATE
    Inherits System.Web.UI.Page

End Class
