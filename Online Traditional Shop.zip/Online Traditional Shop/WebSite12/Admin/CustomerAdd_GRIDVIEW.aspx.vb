﻿
Partial Class Admin_CustomerAdd_GRIDVIEW
    Inherits System.Web.UI.Page

End Class
