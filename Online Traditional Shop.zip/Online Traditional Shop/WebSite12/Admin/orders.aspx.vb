﻿
Partial Class Admin_orders
    Inherits System.Web.UI.Page

End Class
