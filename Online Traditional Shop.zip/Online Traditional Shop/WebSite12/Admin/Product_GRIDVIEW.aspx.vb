﻿
Partial Class Admin_Product_GRIDVIEW
    Inherits System.Web.UI.Page

End Class
