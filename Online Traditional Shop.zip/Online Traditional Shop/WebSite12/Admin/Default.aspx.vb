﻿
Partial Class Admin_Default
    Inherits System.Web.UI.Page

End Class
